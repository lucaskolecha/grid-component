import './productGrid.css';

let Component = {
    template: require('./productGrid.html'),
    controller: function () {

        let ctrl = this;

        ctrl.list = [];

        ctrl.addList = function (size) {
            ctrl.list.push({
                label: size.name,
                custo: ctrl.custo
            });
        }

        ctrl.removeList = function (size) {
            let index = ctrl.list.indexOf(size);
            ctrl.list.splice(index, 1);
        }

    },
    bindings: {
        colors: '=',
        sizes: "=",
        bars: "="
    }
}

export default Component;