import productGrid from './productGrid.js';

angular.module('mobiageGrid', []).component('grid', productGrid);